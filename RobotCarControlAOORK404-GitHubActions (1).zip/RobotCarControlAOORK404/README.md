# Robot Car Control AO ORK404

Aplicación Android nativa en Kotlin + Jetpack Compose para controlar un Arduino mediante **Bluetooth clásico RFCOMM/SPP** (HC-05/HC-06). No utiliza BLE ni finge conexiones: solo muestra conectado después de abrir un socket RFCOMM real con el UUID estándar SPP `00001101-0000-1000-8000-00805F9B34FB`.

## Funciones

- Lista dispositivos Bluetooth **ya emparejados**; el emparejamiento inicial se hace desde Ajustes de Android.
- Permiso `BLUETOOTH_CONNECT` solicitado en Android 12 o posterior; permisos legacy declarados para Android 11 e inferior.
- Conexión/desconexión RFCOMM real, estado visible y errores de conexión en pantalla.
- Controles mantenidos: W avanzar, S retroceder, A izquierda, D derecha. Al levantar el dedo siempre envía el comando configurado para X (STOP).
- Repetición configurable mientras se mantiene pulsado (50–2000 ms) o envío único al pulsar.
- Configuración de las cadenas W/S/A/D/X y terminador opcional: ninguno, LF o CRLF. Los valores se guardan en el teléfono.
- Diseño oscuro gamer con acentos azul neón, marca AO ORK404.

## Protocolo predeterminado

Se envía texto UTF-8 por el puerto serie Bluetooth: `W`, `S`, `A`, `D` y `X`, sin salto de línea por defecto. El firmware del Arduino debe leer esos mismos caracteres. Para protocolos delimitados por línea, elige LF o CRLF en la app y adapta el firmware.

Ejemplo mínimo de lectura (adapta las funciones de motor al driver y al cableado de tu carrito):

```cpp
#include <SoftwareSerial.h>
SoftwareSerial bluetooth(10, 11); // Arduino RX, TX

void setup() {
  Serial.begin(9600);
  bluetooth.begin(9600); // HC-05 suele usar 9600 en modo de datos
  // Configura aquí los pines del puente H.
}

void loop() {
  if (!bluetooth.available()) return;
  char c = bluetooth.read();
  switch (c) {
    case 'W': avanzar(); break;
    case 'S': retroceder(); break;
    case 'A': izquierda(); break;
    case 'D': derecha(); break;
    case 'X': detenerMotores(); break;
  }
}
```

Las funciones `avanzar()`, `retroceder()`, `izquierda()`, `derecha()` y `detenerMotores()` deben implementarse según tu controlador de motores. No conectes el pin TX de 5 V del Arduino directamente al RX del HC-05: usa divisor de voltaje o conversor de nivel; comparte GND. Los pines RX/TX del ejemplo corresponden al lado Arduino; crúzalos con TX/RX del HC-05.

## Compilar e instalar

1. Instala Android Studio y un JDK 17 (Android Studio incluye un JDK compatible).
2. Abre la carpeta `RobotCarControlAOORK404` en Android Studio y deja que Gradle sincronice. Instala Android SDK Platform 35 si Android Studio la solicita.
3. Para generar el APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El archivo de depuración quedará en `app/build/outputs/apk/debug/app-debug.apk`.
4. Instala ese APK en el teléfono, o conecta el teléfono con depuración USB y pulsa **Run** en Android Studio.
5. En el teléfono, abre Ajustes > Bluetooth, empareja primero el HC-05 (PIN común `1234` o `0000`, depende del módulo). Luego abre la app, concede el permiso de dispositivos cercanos y selecciona el módulo.

También se puede compilar desde una terminal con Gradle instalado:

```bash
gradle assembleDebug
```

El proyecto requiere conexión a internet durante la primera sincronización para descargar Gradle/Android Gradle Plugin y dependencias. La compilación/instalación en un teléfono real y el comportamiento del carrito dependen del SDK disponible, el emparejamiento, el módulo y el firmware/cableado del Arduino.

## Compilar el APK con GitHub Actions

El proyecto incluye `.github/workflows/android-apk.yml`. GitHub Actions instala JDK 17, Gradle 8.9 y Android SDK 35, compila el APK de depuración y lo adjunta como artefacto descargable (retención de 30 días).

1. Crea un repositorio de GitHub para **este proyecto Android** y sube el contenido de la carpeta `RobotCarControlAOORK404` a la raíz del repositorio. No mezcles estos archivos con el repositorio de otro proyecto.
2. En GitHub, abre la pestaña **Actions** y habilita los workflows si GitHub te lo solicita. La compilación se inicia al subir cambios a `main`/`master`; también puedes iniciarla manualmente desde el workflow **Build Android APK** con **Run workflow**.
3. Abre la ejecución más reciente y, al terminar correctamente, baja hasta **Artifacts**. Descarga `RobotCarControlAOORK404-debug-apk.zip` y extrae `app-debug.apk`.
4. Instala `app-debug.apk` en Android. Para distribuir la app fuera de pruebas conviene generar una versión release firmada; este workflow produce un APK debug.

El workflow prepara la compilación pero no sube el proyecto, no publica una release ni cambia la configuración de tu cuenta de GitHub.
