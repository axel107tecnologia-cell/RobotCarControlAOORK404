package com.aoork404.robotcar

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.util.UUID

/** RFCOMM Serial Port Profile transport used by HC-05/HC-06 modules. */
class BluetoothSppClient {
    companion object {
        // Standard Bluetooth Serial Port Profile UUID (SPP).
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    @Volatile private var socket: BluetoothSocket? = null

    @Synchronized
    @Throws(IOException::class)
    fun connect(device: BluetoothDevice) {
        closeLocked()
        val candidate = device.createRfcommSocketToServiceRecord(SPP_UUID)
        try {
            candidate.connect()
            socket = candidate
        } catch (e: Exception) {
            try { candidate.close() } catch (_: Exception) {}
            throw e
        }
    }

    @Synchronized
    @Throws(IOException::class)
    fun send(bytes: ByteArray) {
        val active = socket ?: throw IOException("No hay una conexión Bluetooth activa.")
        try {
            active.outputStream.write(bytes)
            active.outputStream.flush()
        } catch (e: IOException) {
            closeLocked()
            throw e
        }
    }

    @Synchronized
    fun isConnected(): Boolean = socket?.isConnected == true

    @Synchronized
    fun disconnect() {
        closeLocked()
    }

    private fun closeLocked() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }
}
