package com.aoork404.robotcar

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

private val Neon = Color(0xFF00D9FF)
private val NeonBlue = Color(0xFF168BFF)
private val Background = Color(0xFF070A12)
private val Panel = Color(0xFF101827)
private val TextMain = Color(0xFFEAF8FF)
private val TextMuted = Color(0xFF91A6B5)

class MainActivity : ComponentActivity() {
    private val spp = BluetoothSppClient()
    private val activityScope get() = lifecycleScope
    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(7, 10, 18)
        setContent { RobotCarScreen() }
    }

    @Composable
    private fun RobotCarScreen() {
        val prefs = remember { getSharedPreferences("robot_car_settings", MODE_PRIVATE) }
        var devices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
        var selected by remember { mutableStateOf<BluetoothDevice?>(null) }
        var connected by remember { mutableStateOf(false) }
        var connecting by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Desconectado") }
        var error by remember { mutableStateOf("") }
        var activeKey by remember { mutableStateOf<String?>(null) }
        var menuExpanded by remember { mutableStateOf(false) }
        var settingsExpanded by remember { mutableStateOf(false) }
        var repeatWhileHeld by remember { mutableStateOf(prefs.getBoolean("repeat", true)) }
        var intervalText by remember { mutableStateOf(prefs.getInt("interval", 150).toString()) }
        var terminator by remember { mutableStateOf(prefs.getString("terminator", "Ninguno") ?: "Ninguno") }
        var cmdW by remember { mutableStateOf(prefs.getString("cmdW", "W") ?: "W") }
        var cmdS by remember { mutableStateOf(prefs.getString("cmdS", "S") ?: "S") }
        var cmdA by remember { mutableStateOf(prefs.getString("cmdA", "A") ?: "A") }
        var cmdD by remember { mutableStateOf(prefs.getString("cmdD", "D") ?: "D") }
        var cmdX by remember { mutableStateOf(prefs.getString("cmdX", "X") ?: "X") }
        var movementJob by remember { mutableStateOf<Job?>(null) }

        fun persist() {
            prefs.edit()
                .putBoolean("repeat", repeatWhileHeld)
                .putInt("interval", intervalText.toIntOrNull()?.coerceIn(50, 2000) ?: 150)
                .putString("terminator", terminator)
                .putString("cmdW", cmdW).putString("cmdS", cmdS)
                .putString("cmdA", cmdA).putString("cmdD", cmdD).putString("cmdX", cmdX)
                .apply()
        }
        LaunchedEffect(repeatWhileHeld, intervalText, terminator, cmdW, cmdS, cmdA, cmdD, cmdX) { persist() }

        fun permissionGranted(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

        fun refreshPaired() {
            error = ""
            if (!permissionGranted()) {
                status = "Se necesita permiso Bluetooth"
                return
            }
            try {
                val adapter = bluetoothAdapter
                if (adapter == null) { error = "Este dispositivo no tiene Bluetooth."; return }
                if (!adapter.isEnabled) { status = "Bluetooth apagado"; return }
                devices = adapter.bondedDevices.orEmpty().sortedBy { it.name ?: it.address }
                if (selected !in devices) selected = devices.firstOrNull()
                if (devices.isEmpty()) status = "No hay dispositivos emparejados"
            } catch (e: SecurityException) {
                error = "Android bloqueó el acceso a los dispositivos Bluetooth. Concede el permiso y vuelve a intentar."
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) refreshPaired()
            else error = "Permiso Bluetooth denegado. Actívalo en Ajustes para buscar dispositivos emparejados."
        }
        val enableLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshPaired()
        }
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !permissionGranted()) {
                permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
            } else refreshPaired()
        }

        fun requestPermissionOrRefresh() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !permissionGranted()) {
                permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
            } else refreshPaired()
        }

        fun connect() {
            val device = selected ?: run { error = "Selecciona un dispositivo emparejado primero."; return }
            if (!permissionGranted()) { requestPermissionOrRefresh(); return }
            error = ""
            connecting = true
            status = "Conectando a ${device.name ?: device.address}…"
            activityScope.launch {
                try {
                    withContext(Dispatchers.IO) { bluetoothAdapter?.cancelDiscovery(); spp.connect(device) }
                    connected = true
                    status = "Conectado a ${device.name ?: device.address}"
                    error = ""
                } catch (e: SecurityException) {
                    status = "Error de conexión"
                    error = "Permiso Bluetooth insuficiente. Revisa el permiso Dispositivos cercanos."
                } catch (e: Exception) {
                    status = "Error de conexión"
                    error = friendlyBluetoothError(e)
                    connected = false
                    withContext(Dispatchers.IO) { spp.disconnect() }
                } finally { connecting = false }
            }
        }

        fun encoded(command: String): ByteArray {
            val suffix = when (terminator) { "LF" -> "\n"; "CRLF" -> "\r\n"; else -> "" }
            return (command + suffix).toByteArray(Charsets.UTF_8)
        }
        fun sendStop() {
            activeKey = null
            movementJob?.cancel()
            movementJob = null
            val stopPayload = encoded(cmdX)
            if (connected) activityScope.launch(Dispatchers.IO) {
                try { spp.send(stopPayload) } catch (e: Exception) {
                    withContext(Dispatchers.Main) { connected = false; status = "Conexión perdida"; error = "No se pudo enviar STOP: ${e.message ?: "error de Bluetooth"}" }
                }
            }
        }
        fun pressMove(key: String, command: String) {
            if (!connected) { error = "Conecta primero el módulo HC-05."; return }
            movementJob?.cancel()
            activeKey = key
            val movementPayload = encoded(command)
            val shouldRepeat = repeatWhileHeld
            val intervalMs = (intervalText.toIntOrNull() ?: 150).coerceIn(50, 2000).toLong()
            movementJob = activityScope.launch(Dispatchers.IO) {
                try {
                    do {
                        spp.send(movementPayload)
                        if (!shouldRepeat) break
                        delay(intervalMs)
                    } while (true)
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { connected = false; activeKey = null; status = "Conexión perdida"; error = "Error enviando comando: ${e.message ?: "sin respuesta"}" }
                }
            }
        }
        fun disconnect() {
            movementJob?.cancel(); movementJob = null; activeKey = null
            val stopPayload = encoded(cmdX)
            activityScope.launch(Dispatchers.IO) {
                try { if (spp.isConnected()) spp.send(stopPayload) } catch (_: Exception) {}
                spp.disconnect()
                withContext(Dispatchers.Main) { connected = false; connecting = false; status = "Desconectado"; error = "" }
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Neon, secondary = NeonBlue, background = Background,
            surface = Panel, onBackground = TextMain, onSurface = TextMain
        )) {
            Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                Column(
                    modifier = Modifier.fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF0C1727), Background, Color(0xFF05070D))))
                        .windowInsetsPadding(androidx.compose.foundation.layout.WindowInsets.safeDrawing)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1420)),
                        border = BorderStroke(1.dp, Color(0xFF17445B)),
                        shape = RoundedCornerShape(26.dp),
                        modifier = Modifier.fillMaxWidth().shadow(14.dp, RoundedCornerShape(26.dp), ambientColor = Neon.copy(alpha = 0.22f))
                    ) {
                        Box(Modifier.fillMaxWidth().height(180.dp)) {
                            Image(
                                painter = painterResource(id = R.drawable.robot_car_hero),
                                contentDescription = "Carrito robot de AO ORK404",
                                modifier = Modifier.align(Alignment.CenterEnd).size(174.dp).clip(RoundedCornerShape(22.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                Modifier.matchParentSize().background(
                                    Brush.horizontalGradient(listOf(Color(0xFF0B1420), Color(0xF20B1420), Color(0x990B1420), Color.Transparent))
                                )
                            )
                            Column(Modifier.align(Alignment.CenterStart).padding(start = 17.dp, top = 14.dp, bottom = 14.dp).width(218.dp)) {
                                Text("AO ORK404  //  GARAGE", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.6.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("ROBOT\nCONTROL", color = TextMain, fontSize = 27.sp, lineHeight = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("TACTICAL DRIVE SYSTEM", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(7.dp).shadow(7.dp, CircleShape, ambientColor = Neon).background(if (connected) Neon else Color(0xFFFF5269), CircleShape))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (connected) "LINK ONLINE" else "HC-05 // STANDBY", color = if (connected) Neon else TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))

                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xE6101827)), border = BorderStroke(1.dp, Color(0xFF1B4059)), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("BLUETOOTH LINK  /  SPP", color = Neon, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp)
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).background(if (connected) Color(0xFF073447) else Color(0xFF271821), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(if (connected) Icons.Default.Bluetooth else Icons.Default.BluetoothDisabled, null,
                                        tint = if (connected) Neon else Color(0xFFFF657A), modifier = Modifier.size(23.dp))
                                }
                                Spacer(Modifier.width(11.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (connected) "LINK ESTABLECIDO" else if (connecting) "SINCRONIZANDO…" else "EN ESPERA", color = if (connected) Neon else TextMain, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 0.7.sp)
                                    Text(status, color = TextMuted, fontSize = 11.sp, maxLines = 2)
                                }
                                Surface(shape = RoundedCornerShape(50), color = if (connected) Color(0xFF073447) else Color(0xFF211923), border = BorderStroke(1.dp, if (connected) Neon.copy(alpha = 0.55f) else Color(0xFF62404C))) {
                                    Text(if (connected) "LIVE" else "OFF", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = if (connected) Neon else Color(0xFFFF8392), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(onClick = { menuExpanded = true }, enabled = !connected && !connecting,
                                        shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Neon), modifier = Modifier.fillMaxWidth()) {
                                        Text(selected?.let { "${it.name ?: "Dispositivo"}  •  ${it.address}" } ?: "Elegir emparejado", maxLines = 1, fontSize = 12.sp)
                                    }
                                    DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }, modifier = Modifier.background(Panel)) {
                                        if (devices.isEmpty()) DropdownMenuItem(text = { Text("Sin dispositivos emparejados") }, onClick = { menuExpanded = false })
                                        devices.forEach { device ->
                                            DropdownMenuItem(text = { Text("${device.name ?: "Desconocido"}\n${device.address}", color = TextMain) }, onClick = { selected = device; menuExpanded = false })
                                        }
                                    }
                                }
                                IconButton(onClick = { requestPermissionOrRefresh() }, enabled = !connecting) { Icon(Icons.Default.Refresh, "Actualizar dispositivos", tint = Neon) }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = {
                                    if (bluetoothAdapter?.isEnabled == false) {
                                        try { enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
                                        catch (_: Exception) { error = "No se pudo abrir la solicitud para activar Bluetooth." }
                                    } else connect()
                                }, enabled = !connected && !connecting,
                                    modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(13.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Color(0xFF00131B))) {
                                    Text(if (connecting) "CONECTANDO…" else "CONECTAR", fontWeight = FontWeight.Black)
                                }
                                OutlinedButton(onClick = { disconnect() }, enabled = connected || connecting,
                                    modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, Color(0xFFFF657A))) {
                                    Text("DESCONECTAR", color = Color(0xFFFF8190), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                            if (error.isNotBlank()) {
                                Spacer(Modifier.height(10.dp))
                                Text(error, color = Color(0xFFFF8998), fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("NEON DRIVE PAD", color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp)
                            Text("MANUAL CONTROL  //  01", color = Neon, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        }
                        Text("HOLD TO MOVE", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    }
                    Spacer(Modifier.height(10.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xB90D1522)), border = BorderStroke(1.dp, Color(0xFF17445B)), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            ControlKey("W", "▲  AVANZAR", activeKey == "W", Modifier.size(96.dp, 80.dp), { pressMove("W", cmdW) }, { sendStop() })
                            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                ControlKey("A", "◀  IZQUIERDA", activeKey == "A", Modifier.size(96.dp, 80.dp), { pressMove("A", cmdA) }, { sendStop() })
                                ControlKey("X", "■  STOP", false, Modifier.size(96.dp, 80.dp), { sendStop() }, { })
                                ControlKey("D", "DERECHA  ▶", activeKey == "D", Modifier.size(96.dp, 80.dp), { pressMove("D", cmdD) }, { sendStop() })
                            }
                            ControlKey("S", "▼  RETROCEDER", activeKey == "S", Modifier.size(96.dp, 80.dp), { pressMove("S", cmdS) }, { sendStop() })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Surface(shape = RoundedCornerShape(50), color = Color(0xFF0C1B29), border = BorderStroke(1.dp, if (connected) Neon.copy(alpha = 0.6f) else Color(0xFF27394A))) {
                        Text(if (connected) "  COMANDO // ${activeKey ?: "STANDBY"}  " else "  CONECTA EL HC-05 PARA INICIAR  ", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = if (connected) Neon else TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 0.8.sp)
                    }

                    Spacer(Modifier.height(18.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Color(0xFF18344B)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Settings, null, tint = Neon)
                                Spacer(Modifier.width(8.dp))
                                Text("CONFIGURACIÓN DE PROTOCOLO", modifier = Modifier.weight(1f), color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                TextButton(onClick = { settingsExpanded = !settingsExpanded }) { Text(if (settingsExpanded) "OCULTAR" else "EDITAR", color = Neon, fontSize = 11.sp) }
                            }
                            Text("SPP · RFCOMM · UUID estándar 00001101… · HC-05", color = TextMuted, fontSize = 11.sp)
                            if (settingsExpanded) {
                                Spacer(Modifier.height(12.dp))
                                Text("Bytes enviados para cada movimiento", color = TextMuted, fontSize = 11.sp)
                                Spacer(Modifier.height(7.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                    CommandField("W", cmdW, { cmdW = it }, Modifier.weight(1f))
                                    CommandField("S", cmdS, { cmdS = it }, Modifier.weight(1f))
                                    CommandField("A", cmdA, { cmdA = it }, Modifier.weight(1f))
                                    CommandField("D", cmdD, { cmdD = it }, Modifier.weight(1f))
                                    CommandField("X", cmdX, { cmdX = it }, Modifier.weight(1f))
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = repeatWhileHeld, onCheckedChange = { repeatWhileHeld = it }, colors = CheckboxDefaults.colors(checkedColor = Neon, checkmarkColor = Background))
                                    Text("Repetir mientras mantengo pulsado", color = TextMain, fontSize = 12.sp)
                                }
                                if (repeatWhileHeld) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Intervalo", color = TextMuted, fontSize = 12.sp)
                                        Spacer(Modifier.width(10.dp))
                                        OutlinedTextField(value = intervalText, onValueChange = { intervalText = it.filter(Char::isDigit).take(4) },
                                            modifier = Modifier.width(92.dp), singleLine = true, suffix = { Text("ms", color = TextMuted) },
                                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, unfocusedBorderColor = Color(0xFF35526A), focusedTextColor = TextMain, unfocusedTextColor = TextMain))
                                        Spacer(Modifier.width(8.dp))
                                        Text("50–2000 ms", color = TextMuted, fontSize = 10.sp)
                                    }
                                }
                                Spacer(Modifier.height(7.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Final de línea", color = TextMuted, fontSize = 12.sp)
                                    Spacer(Modifier.width(10.dp))
                                    listOf("Ninguno", "LF", "CRLF").forEach { option ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(selected = terminator == option, onClick = { terminator = option }, colors = RadioButtonDefaults.colors(selectedColor = Neon))
                                            Text(option, color = TextMain, fontSize = 11.sp)
                                        }
                                    }
                                }
                                Text("La aplicación envía texto UTF-8. Configura el firmware Arduino para interpretar estos mismos comandos.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("AO ORK404  //  BUILT FOR THE GARAGE", color = Color(0xFF456075), fontSize = 9.sp, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }

    @Composable
    private fun ControlKey(label: String, caption: String, active: Boolean, modifier: Modifier, onPress: () -> Unit, onRelease: () -> Unit) {
        val isStop = label == "X"
        val border = if (isStop) Color(0xFFFF5269) else Neon
        val fill = when { active -> Color(0xFF07435A); isStop -> Color(0xFF32131F); else -> Color(0xFF111D2C) }
        Surface(
            modifier = modifier
                .shadow(if (active) 20.dp else 7.dp, RoundedCornerShape(18.dp), ambientColor = border, spotColor = border)
                .pointerInput(label) {
                    detectTapGestures(onPress = {
                        onPress()
                        try { awaitRelease() } finally { onRelease() }
                    })
                }
                .semantics { role = Role.Button; contentDescription = "$label, $caption" },
            shape = RoundedCornerShape(18.dp), color = fill, border = BorderStroke(if (active) 2.dp else 1.dp, border),
            shadowElevation = 0.dp
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(label, color = if (isStop) Color(0xFFFF7184) else TextMain, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(caption, color = if (isStop) Color(0xFFFF8998) else Neon, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 0.35.sp, maxLines = 1, textAlign = TextAlign.Center)
            }
        }
    }

    @Composable
    private fun CommandField(label: String, value: String, onValueChange: (String) -> Unit, modifier: Modifier) {
        Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = value, onValueChange = { onValueChange(it.take(8)) }, singleLine = true,
                modifier = Modifier.height(54.dp),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, textAlign = TextAlign.Center),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, unfocusedBorderColor = Color(0xFF35526A), focusedTextColor = TextMain, unfocusedTextColor = TextMain))
        }
    }

    private fun friendlyBluetoothError(e: Exception): String {
        val detail = e.localizedMessage.orEmpty()
        return when {
            detail.contains("timeout", ignoreCase = true) -> "Tiempo agotado. Confirma que el HC-05 esté encendido, emparejado y dentro del alcance."
            detail.contains("refused", ignoreCase = true) || detail.contains("unreachable", ignoreCase = true) -> "El módulo rechazó la conexión. Verifica el emparejamiento y que no esté conectado a otro dispositivo."
            e is IOException -> "No se pudo abrir el enlace RFCOMM/SPP. Comprueba que el módulo esté emparejado y prueba de nuevo. (${detail.ifBlank { "I/O Bluetooth" }})"
            else -> "No se pudo conectar: ${detail.ifBlank { e.javaClass.simpleName }}"
        }
    }
}

